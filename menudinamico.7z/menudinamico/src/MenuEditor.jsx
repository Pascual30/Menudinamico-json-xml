import { useState } from "react";

export default function MenuEditor({ menu, setMenu }) {
  const [form, setForm] = useState({
    id: "",
    nombre: "",
    enlace: "",
    icono: ""
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
  };

  const agregarElemento = () => {
    // VALIDACIONES
    if (!form.id || !form.nombre || !form.enlace) {
      alert("Campos requeridos no pueden estar vacíos.");
      return;
    }

    if (menu.some(m => m.id == form.id)) {
      alert("El ID ya existe ❌");
      return;
    }

    if (!form.enlace.startsWith("/")) {
      alert("El enlace debe iniciar con '/' ❌");
      return;
    }

    const nuevo = [...menu, form];
    setMenu(nuevo);

    // Guardar en localStorage para persistencia
    localStorage.setItem("menu", JSON.stringify(nuevo));

    alert("Elemento agregado ✔");
  };

  return (
    <div className="editor">
      <h3>Agregar opción al menú</h3>

      <input type="number" name="id" placeholder="ID" onChange={handleChange} />
      <input type="text" name="nombre" placeholder="Nombre" onChange={handleChange} />
      <input type="text" name="enlace" placeholder="Enlace (/ruta)" onChange={handleChange} />
      <input type="text" name="icono" placeholder="Icono (opcional)" onChange={handleChange} />

      <button onClick={agregarElemento}>Agregar</button>
    </div>
  );
}
