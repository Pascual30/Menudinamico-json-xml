import { useEffect, useState } from "react";

export default function Menu() {
  const [menu, setMenu] = useState([]);

  useEffect(() => {
    cargarMenu();
  }, []);

  const cargarMenu = async () => {
    const res = await fetch("/menu.json");
    const data = await res.json();
    setMenu(data.menu);
  };

  return (
    <nav className="menu">
      <ul>
        {menu.map(item => (
          <MenuItem key={item.id} item={item} />
        ))}
      </ul>
    </nav>
  );
}

function MenuItem({ item }) {
  return (
    <li className="menu-item">
      <a href={item.enlace}>
        {item.icono && <i className={`icon-${item.icono}`}></i>}
        {item.nombre}
      </a>

      {item.submenu && (
        <ul className="submenu">
          {item.submenu.map(sub => (
            <li key={sub.id}>
              <a href={sub.enlace}>{sub.nombre}</a>
            </li>
          ))}
        </ul>
      )}
    </li>
  );
}
